/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { 
  MessageCircle,
  Phone, 
  CheckCircle2, 
  Paintbrush, 
  Home, 
  Building2, 
  MapPin,
  Clock,
  Award,
  ChevronRight,
  Menu,
  X,
  Star,
  Quote
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useState, useEffect } from 'react';

const colors = {
  primary: "#2563eb",
  primaryDark: "#1d4ed8",
  secondary: "#0f172a",
  accent: "#3b82f6",
};

export default function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const phoneNumber = "07851348780";
  const displayPhone = "07851 348 780";
  const whatsappNumber = "447851348780";
  const whatsappLink = `https://wa.me/${whatsappNumber}?text=Hi%20B%26D%20Painters,%20I'd%20like%20to%20request%20a%20free%20quote.`;
  const facebookLink = "https://www.facebook.com/profile.php?id=61586236787355"; // Direct profile URL
  const instagramLink = "https://www.instagram.com/"; // Replace with your actual IG page link

  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header 
        className={`fixed w-full z-50 transition-all duration-300 ${
          scrolled ? 'bg-white shadow-md py-3' : 'bg-transparent py-5'
        }`}
      >
        <div className="container mx-auto px-4 md:px-6 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-brand-600 p-2 rounded-lg">
              <Paintbrush className="text-white w-6 h-6" />
            </div>
            <span className={`text-xl font-bold font-display ${scrolled ? 'text-brand-900' : 'text-white md:text-brand-900'}`}>
              B&D Painters
            </span>
          </div>

          <nav className="hidden md:flex items-center gap-8">
            <a href="#services" className={`hover:text-brand-600 font-medium transition-colors ${scrolled ? 'text-slate-600' : 'text-white'}`}>Services</a>
            <a href="#gallery" className={`hover:text-brand-600 font-medium transition-colors ${scrolled ? 'text-slate-600' : 'text-white'}`}>Work</a>
            <div className="flex items-center gap-5">
              <div className="flex items-center gap-3 bg-white/10 backdrop-blur-md py-1.5 px-4 rounded-full border border-white/20 whitespace-nowrap">
                <span className={`text-[10px] font-black uppercase tracking-widest ${scrolled ? 'text-brand-600' : 'text-brand-200'}`}>Call us:</span>
                <div className="flex items-center gap-3">
                  <a href={`tel:${phoneNumber}`} className={`text-lg font-black hover:text-brand-600 transition-colors tracking-tight ${scrolled ? 'text-brand-900' : 'text-white'} whitespace-nowrap`}>
                    {displayPhone}
                  </a>
                  <motion.a 
                    href={whatsappLink}
                    target="_blank"
                    rel="noreferrer noopener"
                    whileHover={{ scale: 1.15, rotate: 10 }}
                    whileTap={{ scale: 0.9 }}
                    className="bg-[#25D366] text-white p-1 rounded-full shadow-lg"
                    title="Chat on WhatsApp"
                  >
                    <MessageCircle size={16} fill="currentColor" className="text-[#25D366] fill-white" />
                  </motion.a>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <motion.a 
                  href={facebookLink} 
                  target="_blank" 
                  rel="noreferrer noopener"
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  className={`p-2 rounded-full transition-all border ${
                    scrolled 
                    ? 'text-brand-600 border-brand-100 hover:bg-brand-50' 
                    : 'text-white border-white/20 hover:bg-white/10'
                  }`}
                  title="Follow us on Facebook"
                >
                  <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24"><path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"></path></svg>
                </motion.a>
                
                <motion.a 
                  href={`tel:${phoneNumber}`}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  animate={{ 
                    boxShadow: ["0px 0px 0px 0px rgba(37, 99, 235, 0)", "0px 0px 0px 10px rgba(37, 99, 235, 0.1)", "0px 0px 0px 0px rgba(37, 99, 235, 0)"] 
                  }}
                  transition={{ repeat: Infinity, duration: 2 }}
                  className="bg-brand-600 hover:bg-brand-900 text-white px-5 py-2.5 rounded-full font-bold flex items-center gap-2 transition-all shadow-lg hover:shadow-xl"
                >
                  <Phone size={18} />
                  Book Now
                </motion.a>
              </div>
            </div>
          </nav>

          <button 
            className="md:hidden text-brand-900"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={28} /> : <Menu size={28} className={scrolled ? 'text-brand-900' : 'text-white'} />}
          </button>
        </div>
      </header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 z-40 bg-white pt-24 px-6 md:hidden"
          >
            <nav className="flex flex-col gap-6 text-xl font-medium">
              <a href="#services" onClick={() => setIsMenuOpen(false)}>Services</a>
              <a href="#gallery" onClick={() => setIsMenuOpen(false)}>Recent Work</a>
              <a 
                href={facebookLink} 
                target="_blank" 
                rel="noreferrer noopener"
                className="flex items-center gap-3 text-slate-700"
                onClick={() => setIsMenuOpen(false)}
              >
                <div className="bg-brand-100 p-2 rounded-lg text-brand-600">
                  <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24"><path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"></path></svg>
                </div>
                Facebook Page
              </a>
              <div className="flex flex-col gap-3 mt-2">
                <a 
                  href={`tel:${phoneNumber}`}
                  className="bg-brand-600 text-white px-6 py-4 rounded-xl flex items-center justify-center gap-3"
                  onClick={() => setIsMenuOpen(false)}
                >
                  <Phone />
                  Call: {displayPhone}
                </a>
                <a 
                  href={whatsappLink}
                  target="_blank" 
                  rel="noreferrer noopener"
                  className="bg-[#25D366] text-white px-6 py-4 rounded-xl flex items-center justify-center gap-3"
                  onClick={() => setIsMenuOpen(false)}
                >
                  <MessageCircle />
                  WhatsApp Message
                </a>
              </div>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>

      <main>
        {/* Hero Section */}
        <section className="relative min-h-[90vh] flex items-center pt-20 overflow-hidden">
          <div className="absolute inset-0 z-0">
            <img 
              src="https://images.unsplash.com/photo-1599690925058-90e1a0b46154?q=80&w=2070&auto=format&fit=crop" 
              alt="Wall texture"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            {/* Dark gradient overlay for readability */}
            <div className="absolute inset-0 bg-gradient-to-r from-slate-900/95 via-slate-900/70 to-transparent"></div>
          </div>

          {/* Painter Image on the right */}
          <div className="absolute top-0 right-0 w-1/2 h-full hidden lg:block z-0 pointer-events-none">
            <motion.div 
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 1, delay: 0.5 }}
              className="relative w-full h-full"
            >
              <img 
                src="https://images.unsplash.com/photo-1562259949-e8e7689d7828?q=80&w=2070&auto=format&fit=crop" 
                alt="Painter on a ladder"
                className="w-full h-full object-cover rounded-l-[100px] shadow-[-20px_0_50px_rgba(0,0,0,0.5)]"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-l from-transparent via-transparent to-slate-900/40 rounded-l-[100px]"></div>
            </motion.div>
          </div>
          
          <div className="container mx-auto px-4 md:px-6 relative z-10 flex items-center min-h-[90vh]">
            <motion.div 
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="max-w-3xl"
            >
              <span className="inline-block px-4 py-1.5 bg-brand-600 border border-brand-600/30 text-white rounded-full text-sm font-black uppercase tracking-widest mb-6 shadow-lg">
                Local Blackpool Decorators
              </span>
              <h1 className="text-5xl md:text-8xl font-black text-white mb-6 leading-[0.95] tracking-tighter drop-shadow-2xl">
                Professional <br className="hidden md:block" />
                Painting & <br className="hidden md:block" />
                Decorating in <span className="text-brand-600 block md:inline">Blackpool</span>
              </h1>
              <p className="text-xl text-slate-100 mb-8 max-w-2xl leading-relaxed drop-shadow-lg font-medium">
                High-quality finishes at competitive rates. Transforming homes and businesses across the Fylde Coast for years. 
                From feature walls to full exterior restoration, we deliver excellence every time.
              </p>
              <div className="flex flex-col sm:flex-row gap-3 items-center">
                <motion.a 
                  href={`tel:${phoneNumber}`}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  animate={{ 
                    boxShadow: ["0px 0px 0px 0px rgba(37, 99, 235, 0)", "0px 0px 0px 15px rgba(37, 99, 235, 0.2)", "0px 0px 0px 0px rgba(37, 99, 235, 0)"] 
                  }}
                  transition={{ repeat: Infinity, duration: 2.5 }}
                  className="w-full sm:w-auto bg-brand-600 hover:bg-brand-900 text-white px-8 py-4 rounded-full font-bold text-lg flex items-center justify-center gap-3 transition-all shadow-2xl"
                >
                  <Phone className="animate-pulse" />
                  {displayPhone}
                </motion.a>
                <div className="text-white/50 font-bold hidden sm:block">OR</div>
                <motion.a 
                  href={whatsappLink}
                  target="_blank"
                  rel="noreferrer noopener"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="w-full sm:w-auto bg-[#25D366] hover:bg-[#128C7E] text-white px-8 py-4 rounded-full font-bold text-lg flex items-center justify-center gap-3 transition-all shadow-xl"
                >
                  <MessageCircle />
                  WhatsApp
                </motion.a>
              </div>
            </motion.div>
          </div>

          <div className="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-slate-50 to-transparent z-10"></div>
        </section>

        {/* Why Choose Us */}
        <section id="about" className="py-24 bg-slate-50">
          <div className="container mx-auto px-4 md:px-6">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-5xl font-bold text-brand-900 mb-6">Why Choose B&D Painters?</h2>
              <div className="h-1.5 w-20 bg-brand-600 mx-auto rounded-full mb-6"></div>
              <p className="text-lg text-slate-600">
                We believe in providing high-end finishes without the premium price tag. 
                Our reputation is built on reliability, craftsmanship, and local trust.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                {
                  title: "Competitive Local Rates",
                  desc: "We provide high-end finishes without the premium price tag. Transparent pricing every time.",
                  icon: <Award className="w-8 h-8 text-brand-600" />
                },
                {
                  title: "Reliable & Local",
                  desc: "Based in Blackpool, we show up on time and treat your property with the utmost respect.",
                  icon: <Clock className="w-8 h-8 text-brand-600" />
                },
                {
                  title: "Expert Craftsmanship",
                  desc: "From feature walls to full exterior masonry, our attention to detail is unmatched.",
                  icon: <Paintbrush className="w-8 h-8 text-brand-600" />
                },
                {
                  title: "Simple Booking",
                  desc: "No complex forms. One phone call and we'll come out for a free, no-obligation quote.",
                  icon: <CheckCircle2 className="w-8 h-8 text-brand-600" />
                }
              ].map((item, i) => (
                <motion.div 
                  key={i}
                  whileHover={{ y: -5 }}
                  className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 transition-all hover:shadow-xl"
                >
                  <div className="mb-6 bg-brand-100 w-16 h-16 rounded-xl flex items-center justify-center">
                    {item.icon}
                  </div>
                  <h3 className="text-xl font-bold text-brand-900 mb-3">{item.title}</h3>
                  <p className="text-slate-600 leading-relaxed">{item.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Services Section */}
        <section id="services" className="py-24 bg-white">
          <div className="container mx-auto px-4 md:px-6">
            <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
              <div className="max-w-2xl">
                <span className="text-brand-600 font-bold uppercase tracking-widest text-sm">Our Expertise</span>
                <h2 className="text-3xl md:text-5xl font-bold text-brand-900 mt-2">Comprehensive Decorating Services</h2>
              </div>
              <p className="text-slate-600 md:max-w-xs">
                Whatever your project, we have the skills and tools to bring your vision to life.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              {[
                {
                  title: "Interior Painting",
                  desc: "Walls, ceilings, woodwork, and master wallpapering delivered with precision and clean finish.",
                  icon: <Home className="w-6 h-6" />,
                  img: "https://images.unsplash.com/photo-1562663474-6cbb3fee4c77?q=80&w=1000&auto=format&fit=crop"
                },
                {
                  title: "Exterior Decorating",
                  desc: "Specialist weatherproof painting designed specifically for Blackpool's harsh coastal climate and masonry.",
                  icon: <Paintbrush className="w-6 h-6" />,
                  img: "https://images.unsplash.com/photo-1518605336324-48055906f24d?q=80&w=1000&auto=format&fit=crop"
                },
                {
                  title: "Commercial Work",
                  desc: "Shops, B&Bs, hotels and offices. We work around your business hours to deliver on schedule.",
                  icon: <Building2 className="w-6 h-6" />,
                  img: "https://images.unsplash.com/photo-1497366216548-37526070297c?q=80&w=1000&auto=format&fit=crop"
                }
              ].map((service, i) => (
                <div key={i} className="group relative overflow-hidden rounded-3xl bg-slate-900 min-h-[300px] flex items-end p-8">
                  <div className="absolute inset-0">
                    <img 
                      src={service.img} 
                      alt={service.title}
                      className="w-full h-full object-cover opacity-60 group-hover:scale-110 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent"></div>
                  </div>
                  
                  <div className="relative z-10 w-full">
                    <div className="flex items-center gap-3 mb-3 text-brand-100">
                      <div className="bg-brand-600 p-2 rounded-lg">
                        {service.icon}
                      </div>
                      <h3 className="text-2xl font-bold text-white">{service.title}</h3>
                    </div>
                    <p className="text-slate-300 mb-6 max-w-md">
                      {service.desc}
                    </p>
                    <a 
                      href={`tel:${phoneNumber}`} 
                      className="inline-flex items-center gap-2 text-white font-semibold hover:text-brand-600 transition-colors group/link"
                    >
                      Get Quote <ChevronRight className="w-4 h-4 group-hover/link:translate-x-1 transition-transform" />
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Gallery Section */}
        <section id="gallery" className="py-24 bg-slate-950 text-white">
          <div className="container mx-auto px-4 md:px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-5xl font-bold mb-4">Recent Work in Blackpool</h2>
              <p className="text-slate-400 max-w-2xl mx-auto">
                Seeing is believing. Here are some of our recently completed projects across the Fylde Coast.
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {[1, 2, 3, 4, 5, 6, 7, 8].map((n) => (
                <motion.div 
                  key={n}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: n * 0.1 }}
                  className="aspect-square overflow-hidden rounded-xl bg-slate-800"
                >
                  <img 
                    src={`https://picsum.photos/seed/painter-${n}/600/600`}
                    alt={`Project ${n}`}
                    className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                    referrerPolicy="no-referrer"
                  />
                </motion.div>
              ))}
            </div>
            
            <div className="mt-12 text-center">
              <a 
                href={`tel:${phoneNumber}`}
                className="inline-flex items-center gap-3 bg-white text-brand-950 px-8 py-4 rounded-full font-bold hover:bg-slate-200 transition-colors"
                id="cta-footer-main"
              >
                <Phone size={20} />
                Book Your Free Quote Today
              </a>
            </div>
          </div>
        </section>

        {/* Testimonials Section */}
        <section id="testimonials" className="py-24 bg-white overflow-hidden">
          <div className="container mx-auto px-4 md:px-6">
            <div className="text-center mb-16">
              <span className="text-brand-600 font-bold uppercase tracking-widest text-sm">Customer Reviews</span>
              <h2 className="text-3xl md:text-5xl font-bold text-brand-900 mt-2">What Our Clients Say</h2>
              <div className="h-1.5 w-20 bg-brand-600 mx-auto rounded-full mt-6"></div>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {[
                {
                  name: "Sarah Jenkins",
                  role: "Homeowner in Lytham",
                  text: "B&D Painters did an incredible job on our hallway and living room. They were so clean and the finish is absolutely perfect. Best decorators we've ever used!",
                  stars: 5
                },
                {
                  name: "David Thompson",
                  role: "Hotel Manager, Blackpool",
                  text: "Extremely professional exterior painting. They worked around our guests and completed the job ahead of schedule. The property looks brand new. Highly recommended.",
                  stars: 5
                },
                {
                  name: "Emma Wilson",
                  role: "Resident in Poulton",
                  text: "The attention to detail on the feature wall wallpapering was amazing. No visible seams and perfectly aligned. Very friendly team and very fair pricing.",
                  stars: 5
                }
              ].map((testimonial, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.2 }}
                  className="bg-slate-50 p-8 rounded-3xl relative border border-slate-100 flex flex-col h-full"
                >
                  <Quote className="absolute top-6 right-8 text-brand-600/10 w-12 h-12" />
                  
                  <div className="flex gap-1 mb-6">
                    {[...Array(testimonial.stars)].map((_, i) => (
                      <Star key={i} size={18} className="fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>

                  <p className="text-slate-600 italic mb-8 flex-grow leading-relaxed">
                    "{testimonial.text}"
                  </p>

                  <div className="flex items-center gap-4 mt-auto">
                    <div className="w-12 h-12 bg-brand-600 rounded-full flex items-center justify-center text-white font-bold text-lg">
                      {testimonial.name.charAt(0)}
                    </div>
                    <div>
                      <h4 className="font-bold text-brand-900">{testimonial.name}</h4>
                      <p className="text-sm text-slate-500 font-medium">{testimonial.role}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Areas Section */},TargetContent:
        <section className="py-16 bg-brand-600">
          <div className="container mx-auto px-4 md:px-6 flex flex-col md:flex-row items-center justify-between gap-8">
            <div>
              <h2 className="text-3xl font-bold text-white mb-2">Service Areas</h2>
              <p className="text-brand-100">Covering the entire Fylde Coast with pride.</p>
            </div>
            <div className="flex flex-wrap justify-center gap-3">
              {['Blackpool', 'Lytham', 'St Annes', 'Bispham', 'Thornton', 'Cleveleys', 'Poulton-le-Fylde'].map((area) => (
                <span key={area} className="px-4 py-2 bg-white/20 backdrop-blur-md rounded-full text-white font-medium border border-white/30">
                  {area}
                </span>
              ))}
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 py-16">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
            <div className="lg:col-span-2">
              <div className="flex items-center gap-2 mb-6">
                <div className="bg-brand-600 p-2 rounded-lg">
                  <Paintbrush className="text-white w-5 h-5" />
                </div>
                <span className="text-xl font-bold font-display text-white">B&D Painters</span>
              </div>
              <p className="max-w-md mb-6">
                Professional painting and decorating services based in Blackpool. 
                We take pride in every stroke, ensuring your home or business looks its absolute best.
              </p>
              <div className="flex items-center gap-4">
                <a 
                  href={facebookLink} 
                  target="_blank" 
                  rel="noreferrer noopener" 
                  className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-brand-600 transition-colors"
                >
                  <span className="sr-only">Facebook</span>
                  <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24"><path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"></path></svg>
                </a>
                <a 
                  href={instagramLink}
                  target="_blank" 
                  rel="noreferrer noopener"
                  className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-brand-600 transition-colors"
                >
                  <span className="sr-only">Instagram</span>
                  <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"></path></svg>
                </a>
              </div>
            </div>

            <div>
              <h4 className="text-white font-bold mb-6">Contact Us</h4>
              <ul className="space-y-4">
                <li className="flex items-center gap-3">
                  <Phone className="w-5 h-5 text-brand-600" />
                  <a href={`tel:${phoneNumber}`} className="hover:text-white transition-colors">
                    Call: {displayPhone}
                  </a>
                </li>
                <li className="flex items-center gap-3">
                  <MessageCircle className="w-5 h-5 text-[#25D366]" />
                  <a href={whatsappLink} target="_blank" rel="noreferrer" className="hover:text-white transition-colors">
                    WhatsApp Chat
                  </a>
                </li>
                <li className="flex items-center gap-3">
                  <MapPin className="w-5 h-5 text-brand-600" />
                  <span>Blackpool, Lancashire, UK</span>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-bold mb-6">Links</h4>
              <ul className="space-y-4">
                <li><a href="#services" className="hover:text-white transition-colors">Services</a></li>
                <li><a href="#about" className="hover:text-white transition-colors">Why Choose Us</a></li>
                <li><a href="#gallery" className="hover:text-white transition-colors">Recent Projects</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
              </ul>
            </div>
          </div>

          <div className="pt-12 border-t border-slate-800 text-sm flex flex-col md:flex-row justify-between items-center gap-4">
            <p>© {new Date().getFullYear()} B&D Painters. All rights reserved.</p>
            <p>Designed for excellence in Blackpool.</p>
          </div>
        </div>
      </footer>

      {/* Floating CTAs for Mobile */}
      <div className="fixed bottom-6 right-6 z-40 flex flex-col gap-4 md:hidden">
        <motion.a 
          href={whatsappLink}
          target="_blank"
          rel="noreferrer noopener"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          className="w-16 h-16 bg-[#25D366] text-white rounded-full flex items-center justify-center shadow-2xl"
        >
          <MessageCircle size={32} />
        </motion.a>
        <motion.a 
          href={`tel:${phoneNumber}`}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          animate={{ 
            scale: [1, 1.1, 1],
            boxShadow: ["0px 0px 0px 0px rgba(37, 99, 235, 0)", "0px 0px 0px 12px rgba(37, 99, 235, 0.3)", "0px 0px 0px 0px rgba(37, 99, 235, 0)"] 
          }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="w-16 h-16 bg-brand-600 text-white rounded-full flex items-center justify-center shadow-2xl"
        >
          <Phone size={28} />
        </motion.a>
      </div>
    </div>
  );
}
